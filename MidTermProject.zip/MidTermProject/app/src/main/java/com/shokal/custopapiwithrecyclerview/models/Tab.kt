package com.shokal.custopapiwithrecyclerview.models

import androidx.fragment.app.Fragment

data class Tab(val fragment: Fragment, val title: String)
