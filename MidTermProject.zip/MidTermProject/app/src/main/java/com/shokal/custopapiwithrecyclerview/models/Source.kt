package com.shokal.custopapiwithrecyclerview.models

data class Source(
    val id: String?,
    val name: String?
)